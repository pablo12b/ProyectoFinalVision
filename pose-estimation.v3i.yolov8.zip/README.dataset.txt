# pose-estimation > 2025-05-20 6:40pm
https://universe.roboflow.com/skripsi-fn4pn/pose-estimation-07d85

Provided by a Roboflow user
License: CC BY 4.0

